# OneCrew Lite 0.9.1 · Windows x64

本包由当前 TypeScript 源码构建，包含主程序、内嵌 Codex 插件、工作台、Library 与只读适配器。主程序 SHA-256：e119eb53bb66923a1b9e8fd989b9395d1c33ec52fded63a3389744b65f7f71cb。

Windows 验证结果与源码树、依赖锁、程序和资源哈希记录在同名 release.json。包内 SHA256SUMS.json 校验所有交付文件。保留用户现有数据、登录、端口和浏览器身份。

包含 Windows SQLite 长路径兼容和历史库备份升级修复；不关闭权限保护。状态卡宿主交互与本地网页检查分别记录，不能互相替代。安装指南与通用提示词包含 SQLite 失败诊断和保留数据的处理步骤。

Mac ARM 和 Mac Intel 验收未完成，mac_installer 未改动。candidate.json 的 productionReady 保留原值，不代表全部平台已完成正式发行验收。
