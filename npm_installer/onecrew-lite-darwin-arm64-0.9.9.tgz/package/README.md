# @onecrew/lite-darwin-arm64

Native OneCrew Lite 0.9.9. Install @onecrew/lite to select the matching platform. The application and third-party notices are included; installation does not run scripts or download another program.
